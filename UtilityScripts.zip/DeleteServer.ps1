Write-Host "Deleting all containers"
docker stop (docker ps -a -q)
docker rm $(docker ps -a -q)

#pause
[void][System.Console]::ReadKey($true)