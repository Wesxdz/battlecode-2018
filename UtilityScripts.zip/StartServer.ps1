
$currentDirectory = '' + (Get-Location)
$buildPath = $currentDirectory + ":/player"

docker pull battlecode/battlecode-2018

Write-Host ""
Write-Host "Deleting all containers"
docker stop (docker ps -a -q)
docker rm $(docker ps -a -q)

Write-Host ""
Write-Host "Starting up the server"
docker run -it --privileged -p 16147:16147 -p 6147:6147 --name "BattleCodeServer" -v $buildPath "battlecode/battlecode-2018"

if(!$?){
	#$absBuildPath = "Your Path" + ":/player";
	Write-Host "Opps it failed. Please open this file, Uncomment $absBuildPath and Set $absBuildPath = to 'the buildpath'"
	docker run -it --privileged -p 16147:16147 -p 6147:6147 --name "BattleCodeServer" -v $absBuildPath "battlecode/battlecode-2018"
}

#pause
[void][System.Console]::ReadKey($true)

